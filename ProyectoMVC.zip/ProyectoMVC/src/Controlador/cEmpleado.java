/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Conexion.conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author gmarl
 */
public class cEmpleado {
    
    private conexion mysql = conexion.getInstancia();
    private Connection cn = mysql.conectar();
    public String sSQL = "";
    public Integer totalRegistros;
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs;

    public DefaultTableModel mostrar(String buscar) {
        DefaultTableModel modelo;
        String[] titulo = {"ID Empleado", "Nombre", "Apellido Paterno", "Apellido Materno","Departamento","Turno", "Inicio Contratación", "Fin Contratación","ID Turno"};
        String[] registro = new String[9];
        totalRegistros = 0;
        modelo = new DefaultTableModel(null, titulo);

        sSQL = "select * from empleado";
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sSQL);

            while (rs.next()) {
                registro[0] = rs.getString("id_empleado");
                registro[1] = rs.getString("nombre");
                registro[2] = rs.getString("apellidopa");
                registro[3] = rs.getString("apellidoma");
                registro[4] = rs.getString("departamento");
                registro[5] = rs.getString("turno");
                registro[6] = rs.getString("inicio_contratacion");
                registro[7] = rs.getString("fin_contratacion");
                registro[8] = rs.getString("id_turno");
                
                totalRegistros = totalRegistros + 1;
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar la tabla: " + e.getMessage());
            return null;
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
                if (cn != null) cn.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
    
}
