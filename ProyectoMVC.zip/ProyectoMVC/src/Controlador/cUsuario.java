package Controlador;


import Conexion.conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class cUsuario {

    private conexion mysql = conexion.getInstancia();
    private Connection cn = mysql.conectar();
    public String sSQL = "";
    public Integer totalRegistros;
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs;

    public DefaultTableModel mostrar(String buscar) {
        DefaultTableModel modelo;
        String[] titulo = {"Nombre", "Contraseña", "Correo Electronico", "Acceso"};
        String[] registro = new String[4];
        totalRegistros = 0;
        modelo = new DefaultTableModel(null, titulo);

        sSQL = "select * from usuario";
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sSQL);

            while (rs.next()) {
                registro[0] = rs.getString("username");
                registro[1] = rs.getString("password");
                registro[2] = rs.getString("correoelectronico");
                registro[3] = rs.getString("acceso");

                totalRegistros = totalRegistros + 1;
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar la tabla: " + e.getMessage());
            return null;
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
                if (cn != null) cn.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}
