package Controlador;

import Conexion.conexion;
import Modelo.mAsistencia;
import Vista.vAsistencia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class cAsistencia {
  
    private conexion mysql = conexion.getInstancia();
    private Connection cn = mysql.conectar();
    public String sSQL = "";
    public Integer totalRegistros;
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs;

    public DefaultTableModel mostrar(String buscar) {
        DefaultTableModel modelo;
        String[] titulo = {"ID Asistencia", "ID Empleado", "Nombre Empleado", "Fecha", "Hora", "Estado"};
        String[] registro = new String[6]; 
        totalRegistros = 0;
        modelo = new DefaultTableModel(null, titulo);

        sSQL = "SELECT * FROM asistencia WHERE nombreEmpleado LIKE '%" + buscar + "%'";

        try {
            st = cn.createStatement();
            rs = st.executeQuery(sSQL);

            while (rs.next()) {
                registro[0] = rs.getString("id_asistencia");
                registro[1] = rs.getString("id_empleado");
                registro[2] = rs.getString("nombreEmpleado");
                registro[3] = rs.getString("fecha");
                registro[4] = rs.getString("hora");
                registro[5] = rs.getString("estado");

                totalRegistros++;
                modelo.addRow(registro);
            }
            return modelo;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar la tabla: " + e.getMessage());
            return null;
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
                // No cerrar la conexión aquí
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }

    public boolean insertar(mAsistencia dts) {
    sSQL = "INSERT INTO asistencia (id_empleado, fecha, hora, estado)"
            + " VALUES (?, ?, ?, ?, ?)";
    try {
        PreparedStatement pst = cn.prepareStatement(sSQL);
        pst.setInt(1, dts.getId_empleado());
        pst.setString(2, dts.getNombreEmpleado());
        pst.setString(3, dts.getFecha());
        pst.setString(4, dts.getHora());
        pst.setString(5, dts.getEstado());

        int rows = pst.executeUpdate();
        return rows > 0;
    } catch (Exception e) {
        JOptionPane.showConfirmDialog(null, "Error al insertar en la tabla: " + e.getMessage());
        return false;
    }
}


    public boolean eliminar(mAsistencia dts) {
        sSQL = "DELETE FROM asistencia WHERE id_asistencia=?";

        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setInt(1, dts.getId_asistencia());

            int n = pst.executeUpdate();

            return n != 0;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error al eliminar en la tabla: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(mAsistencia dts, vAsistencia vista) {
sSQL = "UPDATE asistencia SET id_empleado=?, nombreEmpleado=?, fecha=?, hora=?, estado=? WHERE id_asistencia=?";
        try {
             int ida = Integer.parseInt(vista.txtIDAsistencia.getText().trim());
            int ide = Integer.parseInt(vista.txtIDEmpleado.getText().trim());
            String nombreEmpleado = vista.txtNombreEmpleado.getText().trim();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fecha = sdf.format(vista.txtFecha.getDate());
            String hora = vista.lblHora.getText().trim();
            String estado = vista.cboEstado.getSelectedItem().toString().trim();

            dts.setId_asistencia(ida);
            dts.setId_empleado(ide);
            dts.setNombreEmpleado(nombreEmpleado);
            dts.setFecha(fecha);
            dts.setHora(hora);
            dts.setEstado(estado);

            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setInt(1, dts.getId_empleado());
            pst.setString(2, dts.getNombreEmpleado());
            pst.setString(3, dts.getFecha());
            pst.setString(4, dts.getHora());
            pst.setString(5, dts.getEstado());
            pst.setInt(6, dts.getId_asistencia());

            int n = pst.executeUpdate();

            if (n != 0) {
                JOptionPane.showMessageDialog(null, "Los datos han sido editados exitosamente");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró la asistencia para actualizar");
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error al actualizar en la tabla: " + e.getMessage());
            System.out.println("Error al editar los datos de la asistencia: " + e.getMessage());
            return false;
        }
    }
     public boolean existeEmpleadoPorNombre(String nombreEmpleado) {
        boolean existe = false;
        String query = "SELECT id_empleado FROM empleados WHERE nombre = ?";
        try {
            PreparedStatement pstmt = cn.prepareStatement(query);
            pstmt.setString(1, nombreEmpleado);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                existe = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al ejecutar la consulta: " + e.getMessage());
        }
        return existe;
    }
     public int obtenerIdEmpleadoPorNombre(String nombreEmpleado) {
        int idEmpleado = -1;
        String query = "SELECT id_empleado FROM empleados WHERE nombre = ?";
        try {
            PreparedStatement pstmt = cn.prepareStatement(query);
            pstmt.setString(1, nombreEmpleado);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                idEmpleado = rs.getInt("id_empleado");
            }
        } catch (SQLException e) {
            System.out.println("Error al ejecutar la consulta: " + e.getMessage());
        }
        return idEmpleado;
    } 
    
}
