/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author gmarl
 */
public class mEmpleado {

    private int idempleado;
    private String nombres;
    private String apellidos;
    private String salario;
    private int idturno;
    private int iddepartamento;
    private int idusuario;

    public mEmpleado(int idempleado, String nombres, String apellidos, String salario, int idturno, int iddepartamento, int idusuario) {
        this.idempleado = idempleado;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.salario = salario;
        this.idturno = idturno;
        this.iddepartamento = iddepartamento;
        this.idusuario = idusuario;
    }

  
    public int getIdempleado() { return idempleado; }
    public void setIdempleado(int idempleado) { this.idempleado = idempleado; }
    public String getNombres() { return nombres; }
    public void setNombres(String nombres) { this.nombres = nombres; }
    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }
    public String getSalario() { return salario; }
    public void setSalario(String salario) { this.salario = salario; }
    public int getIdturno() { return idturno; }
    public void setIdturno(int idturno) { this.idturno = idturno; }
    public int getIddepartamento() { return iddepartamento; }
    public void setIddepartamento(int iddepartamento) { this.iddepartamento = iddepartamento; }
    public int getIdusuario() { return idusuario; }
    public void setIdusuario(int idusuario) { this.idusuario = idusuario; }
}
