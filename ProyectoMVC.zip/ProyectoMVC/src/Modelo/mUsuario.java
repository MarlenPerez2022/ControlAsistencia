/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;



/**
 *
 * @author gmarl
 */
public class mUsuario {
    
    private int idusuario;
    private String contra;
    private String correo;
    private String telefono;

    public mUsuario(int idusuario, String contra, String correo, String telefono) {
        this.idusuario = idusuario;
        this.contra = contra;
        this.correo = correo;
        this.telefono = telefono;
    }

    public int getIdusuario() { return idusuario; }
    public void setIdusuario(int idusuario) { this.idusuario = idusuario; }
    public String getContra() { return contra; }
    public void setContra(String contra) { this.contra = contra; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }    
}
