/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import java.sql.Date;
import java.sql.Timestamp;
/**
 *
 * @author gmarl
 */
public class mAsistencia {
  private int idempleado;
    private Date fecha;
    private Timestamp hora;
    private String estado;
    private String descripcion;

    public mAsistencia(int idempleado, Date fecha, Timestamp hora, String estado, String descripcion) {
        this.idempleado = idempleado;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
        this.descripcion = descripcion;
    }

    // Getters y Setters
    public int getIdempleado() { return idempleado; }
    public void setIdempleado(int idempleado) { this.idempleado = idempleado; }
    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }
    public Timestamp getHora() { return hora; }
    public void setHora(Timestamp hora) { this.hora = hora; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
