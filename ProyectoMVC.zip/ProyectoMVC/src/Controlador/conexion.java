package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class conexion {

    private static conexion instancia;
    private Connection link;

    public static conexion getInstancia() {
        if (instancia == null) {
            instancia = new conexion();
        }
        return instancia;
    }

    private final String db = "gestionpersonal";
    private final String url = "jdbc:mysql://localhost:3306/" + db;
    private final String user = "root";
    private final String password = "123456789";

    private conexion() {}

    public Connection conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            link = DriverManager.getConnection(this.url, this.user, this.password);
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al establecer la conexión a la base de datos: " + e.getMessage());
        }
        return link;
    }

    public void desconectar() {
        try {
            if (link != null && !link.isClosed()) {
                link.close();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.getMessage());
        }
    }
}
