/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.util.ArrayList; 
import java.util.List;
import model.*; 
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
/**
 *
 * @author gmarl
 */
public class basededatos {
    private conexion conexion = new conexion();
    private Connection con = conexion.conectar(); 
    
     private List<Asistencia> asistencia;
    private List<Empleado> empleados;
    private List<Puesto> puestos;
    private List<Venta> ventas;
    private List<Cliente> clientes;
    private List<DescripcionVenta> descripcionesVentas;
   
    private void cargarAsistencia(){
        String query = "SELECT * FROM asistencia";        
        try{
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while( rs.next() ){
                //Creacion de un objeto de este tipo con la misma forma que en la BD por cada tupla existente en ella
                Producto producto = new Producto( 
                        rs.getInt(1),   //codigo_producto
                        rs.getString(2),  //nombre_p
                        rs.getDouble(3), //precio_compra_p
                        rs.getDouble(4), //precio_venta_p 
                        rs.getInt(5), //categoria_p
                        rs.getString(6),  // descripcion_p
                        rs.getInt(7)  //Existencia_p                        
                );
                //Lo añadimos a la lista de producos
                productos.add(producto);
            }
            //Bandera de confirmacion
            System.out.println("PRODUCTOS cargados correctamente");            
        }catch(SQLException e){
            System.out.println("ERROR en la carga de los PRODUCTOS: \n" + e);
        }
    }         
}
